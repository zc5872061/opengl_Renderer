//*****************************************************************************
//
//  Copyright (c) 2006-2008 Ralf Knoesel
//  Copyright (c) 2008-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  GfxSceneTriMeshBuilder class
// 
//*****************************************************************************

#pragma once

#include "VuEngine/Containers/VuObjectArray.h"
#include "VuEngine/Math/VuVector3.h"
#include "VuEngine/Json/VuJsonContainer.h"
#include "VuEngine/Util/VuColor.h"

class VuJsonContainer;
class VuMatrix;
class VuCollisionMaterialAsset;


class VuGfxSceneTriMeshBuilder
{
public:
	VuGfxSceneTriMeshBuilder(const std::string &platform, const std::string &sku, const std::string &language, const VuJsonContainer &creationInfo, const VuJsonContainer &data);
	~VuGfxSceneTriMeshBuilder();

	struct Triangle
	{
		int		mMaterialIndex;
		VuColor	mColor0;
		VuColor	mColor1;
		VuColor	mColor2;
	};

	void					build(bool flipX);

	int						getVertCount() const	{ return (int)mVerts.size(); }
	int						getIndexCount() const	{ return (int)mIndices.size(); }
	int						getTriCount() const		{ return (int)mIndices.size()/3; }

	const VuVector3			*getVerts() const			{ return &mVerts[0]; }
	const int				*getIndices() const			{ return &mIndices[0]; }
	const Triangle			*getTris() const			{ return &mTris[0]; }

	int								getMaterialCount() const		{ return (int)mMaterialAssets.size(); }
	const VuCollisionMaterialAsset	*getMaterial(int index) const	{ return mMaterialAssets[index]; }

private:
	typedef VuObjectArray<VuVector3> Verts;
	typedef VuObjectArray<VuColor> Colors;
	typedef VuObjectArray<int> Indices;
	typedef VuObjectArray<Triangle> Tris;
	typedef std::vector<VuCollisionMaterialAsset *> MaterialAssets;
	struct Mesh
	{
		const VuJsonContainer	*mpPartsData;
		Verts					mVerts;
		Colors					mColors;
		Indices					mIndices;
	};
	typedef std::map<std::string, Mesh> Meshes;
	typedef std::set<std::string> Shaders;
	struct Material
	{
		std::string					mName;
		Indices						mIndices;
		Tris						mTris;
	};
	typedef std::vector<Material> Materials;

	void			buildMesh(const VuJsonContainer &data, Mesh &mesh);
	void			gatherTrisRecursive(const VuJsonContainer &data, const VuMatrix &transform);
	void			addTris(const VuJsonContainer &data, const Mesh &mesh, const VuMatrix &transform);

	std::string				mPlatform;
	std::string				mSku;
	std::string				mLanguage;
	const VuJsonContainer	&mCreationInfo;
	const VuJsonContainer	&mData;

	Verts					mVerts;
	Indices					mIndices;
	Tris					mTris;
	MaterialAssets			mMaterialAssets;

	Meshes					mMeshes;
	Materials				mMaterials;
};
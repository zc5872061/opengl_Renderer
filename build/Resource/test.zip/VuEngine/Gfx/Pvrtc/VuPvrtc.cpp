//*****************************************************************************
//
//  Copyright (c) 2011-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  PVRTC util
// 
//*****************************************************************************

#include "VuPvrtc.h"


#if defined VUWIN32 && !VU_DISABLE_BAKING

#include "PVRTC/PVRTC_2.08.28.0634/dll/Windows_x86_32/pvrtc_dll.h"

#pragma comment(lib, "pvrtc.lib")

int VuPvrtc::getStorageRequirements(int width, int height, bool createMipMaps)
{
	return pvrtc_size(width, height, createMipMaps, false);
}

void VuPvrtc::compressImage(const VUUINT8 *argb, int width, int height, VuArray<VUBYTE> &output, bool createMipMaps, bool alphaOn, bool assumeTiles)
{
	output.resize(pvrtc_size(width, height, createMipMaps, false));

	int result = pvrtc_compress((void *)argb, &output[0], width, height, createMipMaps, alphaOn, assumeTiles, false);
}

#else

int VuPvrtc::getStorageRequirements(int width, int height, bool createMipMaps) { return 0; }
void VuPvrtc::compressImage(const VUUINT8 *rgba, int width, int height, VuArray<VUBYTE> &output, bool createMipMaps, bool alphaOn, bool assumeTiles) {}

#endif
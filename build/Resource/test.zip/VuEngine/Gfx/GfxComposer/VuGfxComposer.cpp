//*****************************************************************************
//
//  Copyright (c) 2008-2008 Ralf Knoesel
//  Copyright (c) 2008-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  GfxComposer class
// 
//*****************************************************************************

#include "VuGfxComposer.h"


// the interface
IMPLEMENT_SYSTEM_COMPONENT(VuGfxComposer, VuGfxComposer);

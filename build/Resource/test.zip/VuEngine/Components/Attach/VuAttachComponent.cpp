//*****************************************************************************
//
//  Copyright (c) 2009-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  AttachComponent class
// 
//*****************************************************************************

#include "VuAttachComponent.h"


IMPLEMENT_RTTI(VuAttachComponent, VuComponent);


//*****************************************************************************
//
//  Copyright (c) 2007-2008 Ralf Knoesel
//  Copyright (c) 2008-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Fluids Mesh Asset class
// 
//*****************************************************************************

#include "VuTimedEventAsset.h"
#include "VuAssetUtil.h"
#include "VuEngine/HAL/File/VuFile.h"
#include "VuEngine/Json/VuJsonReader.h"
#include "VuEngine/Json/VuJsonBinaryReader.h"
#include "VuEngine/Json/VuJsonBinaryWriter.h"
#include "VuEngine/Util/VuBinaryDataUtil.h"
#include "VuEngine/Memory/VuScratchPad.h"


IMPLEMENT_RTTI(VuTimedEventAsset, VuAsset);
IMPLEMENT_ASSET_REGISTRATION(VuTimedEventAsset);


//*****************************************************************************
static bool CompareEvents(const VuTimedEventAsset::VuEvent &event1, const VuTimedEventAsset::VuEvent &event2)
{
	return event1.mTime < event2.mTime;
}

//*****************************************************************************
void VuTimedEventAsset::schema(const VuJsonContainer &creationInfo, VuJsonContainer &schema)
{
	schema["DefaultPath"].putValue("TimedEvents");

	VuAssetUtil::addFileProperty(schema, "File", "json");
}

//*****************************************************************************
bool VuTimedEventAsset::bake(const VuJsonContainer &creationInfo, VuAssetBakeParams &bakeParams)
{
	VuBinaryDataWriter &writer = bakeParams.mWriter;

	const std::string &fileName = creationInfo["File"].asString();

	// load json document
	VuJsonContainer doc;
	VuJsonReader reader;
	if ( !reader.loadFromFile(doc, fileName) )
		return VUWARNING("Unable to load fluids mesh asset %s: %s", fileName.c_str(), reader.getLastError().c_str());

	Events events;
	events.resize(doc.size());
	for ( int i = 0; i < doc.size(); i++ )
	{
		events[i].mTime = doc[i]["Time"].asFloat();
		events[i].mType = doc[i]["Type"].asString();
		events[i].mParams = doc[i]["Params"];
	}

	// sort based on time
	std::sort(events.begin(), events.end(), CompareEvents);

	// write count
	writer.writeValue((int)events.size());

	VuJsonBinaryWriter jsonWriter;
	void *pScratchPad = VuScratchPad::get();

	for ( int i = 0; i < (int)events.size(); i++ )
	{
		VuEvent *pEvent = &events[i];

		// write time
		writer.writeValue(pEvent->mTime);

		// write type
		writer.writeString(pEvent->mType);

		// write params using scratch pad
		int paramsSize = VuScratchPad::SIZE;
		if ( !jsonWriter.saveToMemory(pEvent->mParams, pScratchPad, paramsSize) )
			return false;
		writer.writeValue(paramsSize);
		writer.writeData(pScratchPad, paramsSize);
	}
	
	return true;
}

//*****************************************************************************
bool VuTimedEventAsset::load(VuBinaryDataReader &reader)
{
	VuJsonBinaryReader jsonReader;

	// read count
	int eventCount;
	reader.readValue(eventCount);
	mEvents.resize(eventCount);

	void *pScratchPad = VuScratchPad::get();

	for ( int i = 0; i < (int)mEvents.size(); i++ )
	{
		VuEvent *pEvent = &mEvents[i];

		// read time
		reader.readValue(pEvent->mTime);

		// read type
		reader.readString(pEvent->mType);

		// read params using scratch pad
		int paramsSize;
		reader.readValue(paramsSize);
		reader.readData(pScratchPad, paramsSize);
		if ( !jsonReader.loadFromMemory(pEvent->mParams, pScratchPad, paramsSize) )
			return false;
	}

	return true;
}

//*****************************************************************************
void VuTimedEventAsset::unload()
{
	mEvents.clear();
}

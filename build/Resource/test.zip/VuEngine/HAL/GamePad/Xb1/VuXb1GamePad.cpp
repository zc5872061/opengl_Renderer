//*****************************************************************************
//
//  Copyright (c) 2014-2014 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Xb1 interface class for GamePad.
//
//*****************************************************************************

#include "VuEngine/HAL/GamePad/VuGamePad.h"
#include "VuEngine/Managers/VuTickManager.h"
#include "VuEngine/Events/VuEventManager.h"
#include "VuEngine/Dev/VuDevConfig.h"

using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::Xbox::Input;


#define LOW_FREQ_VIBRATION_DECAY_RATE (4.0f) // per second
#define HIGH_FREQ_VIBRATION_DECAY_RATE (1.0f) // per second


class VuXb1GamePad : public VuGamePad
{
public:
	VuXb1GamePad();

	virtual bool	init();
	virtual void	postInit();
	virtual void	release();

	virtual VuController	&getController(int index) { return mControllers[index]; }

private:
	void			tick(float fdt);

	class VuXb1Controller : public VuController
	{
	public:
		VuXb1Controller() : mDeviceId(0), mLowFreq(0.0f), mHighFreq(0.0f) {}

		virtual void	playVibrationEffect(int effect);

		VUUINT32		mDeviceId;
		float			mLowFreq;
		float			mHighFreq;
	};

	VuXb1Controller		mControllers[MAX_NUM_PADS];

	// Vibration
	bool				mRumbleActive;
};


// the interface
IMPLEMENT_SYSTEM_COMPONENT(VuGamePad, VuXb1GamePad);


enum eAxes
{
	AXIS_LEFT_STICK_X,
	AXIS_LEFT_STICK_Y,
	AXIS_RIGHT_STICK_X,
	AXIS_RIGHT_STICK_Y,
	AXIS_LEFT_TRIGGER,
	AXIS_RIGHT_TRIGGER,

	AXIS_COUNT
};


// vibration ffects
struct VibrationEffect { float mLowFreq; float mHighFreq; };
static VibrationEffect sVibrationEffects[] =
{
	{ 0.0f, 0.4f }, // EFFECT_COLLISION_SMALL,
	{ 0.0f, 0.7f }, // EFFECT_COLLISION_MEDIUM,
	{ 0.0f, 1.0f }, // EFFECT_COLLISION_LARGE,
	{ 0.4f, 0.0f }, // EFFECT_SPLASH_SMALL,
	{ 0.7f, 0.0f }, // EFFECT_SPLASH_MEDIUM,
	{ 1.0f, 0.0f }, // EFFECT_SPLASH_LARGE,
};
VU_COMPILE_TIME_ASSERT(sizeof(sVibrationEffects)/sizeof(sVibrationEffects[0]) == VuGamePad::VuController::NUM_EFFECTS);


//*****************************************************************************
VuXb1GamePad::VuXb1GamePad():
	mRumbleActive(true)
{
	addAxis("LEFT_STICK_X", -1.0f, 1.0f);
	addAxis("LEFT_STICK_Y", -1.0f, 1.0f);
	addAxis("RIGHT_STICK_X", -1.0f, 1.0f);
	addAxis("RIGHT_STICK_Y", -1.0f, 1.0f);
	addAxis("LEFT_TRIGGER", 0.0f, 1.0f);
	addAxis("RIGHT_TRIGGER", 0.0f, 1.0f);

	VUASSERT(mAxisDefs.size() == AXIS_COUNT, "VuXInput::VuXInput() axis count mismatch");

	addButton("MENU"); // 4
	addButton("VIEW"); // 8
	addButton("A"); // 16
	addButton("B"); // 32
	addButton("X"); // 64
	addButton("Y"); // 128
	addButton("DPAD_UP"); // 256
	addButton("DPAD_DOWN"); // 512
	addButton("DPAD_LEFT"); // 1024
	addButton("DPAD_RIGHT"); // 2048
	addButton("LEFT_SHOULDER"); // 4096
	addButton("RIGHT_SHOULDER"); // 8192
	addButton("LEFT_THUMB"); // 16384
	addButton("RIGHT_THUMB"); // 32768
}

//*****************************************************************************
bool VuXb1GamePad::init()
{
	if ( !VuGamePad::init() )
		return false;

	// register phased tick
	VuTickManager::IF()->registerHandler(this, &VuXb1GamePad::tick, "Input");

	return true;
}

//*****************************************************************************
void VuXb1GamePad::postInit()
{
	if ( VuDevConfig::IF() )
	{
		VuDevConfig::IF()->getParam("RumbleActive").getValue(mRumbleActive);
	}
}

//*****************************************************************************
void VuXb1GamePad::release()
{
	// unregister phased tick
	VuTickManager::IF()->unregisterHandlers(this);
}

//*****************************************************************************
void VuXb1GamePad::tick(float fdt)
{
	// check for pad disconnections
	for ( VUUINT i = 0; i < MAX_NUM_PADS; i++ )
	{
		VuXb1Controller &controller = mControllers[i];

		if ( i < Gamepad::Gamepads->Size )
		{
			controller.mIsConnected = true;

			IGamepad ^gamepad = Gamepad::Gamepads->GetAt(i);
			IGamepadReading^ reading = gamepad->GetCurrentReading();

			controller.mButtons = (VUUINT32)reading->Buttons >> 2; // Xb1 hardware buttons start at 4 (1<<2)

			controller.mAxes[AXIS_LEFT_STICK_X] = reading->LeftThumbstickX;
			controller.mAxes[AXIS_LEFT_STICK_Y] = reading->LeftThumbstickY;
			controller.mAxes[AXIS_RIGHT_STICK_X] = reading->RightThumbstickX;
			controller.mAxes[AXIS_RIGHT_STICK_Y] = reading->RightThumbstickY;
			controller.mAxes[AXIS_LEFT_TRIGGER] = reading->LeftTrigger;
			controller.mAxes[AXIS_RIGHT_TRIGGER] = reading->RightTrigger;

			// update vibration
			if ( mRumbleActive )
			{
				GamepadVibration vib;
				vib.LeftMotorLevel = controller.mLowFreq;
				vib.RightMotorLevel = controller.mHighFreq;
				vib.LeftTriggerLevel = 0.0f;
				vib.RightTriggerLevel = 0.0f;
				gamepad->SetVibration(vib);
			}

			controller.mLowFreq -= LOW_FREQ_VIBRATION_DECAY_RATE*fdt;
			controller.mHighFreq -= HIGH_FREQ_VIBRATION_DECAY_RATE*fdt;
			controller.mLowFreq = VuMax(controller.mLowFreq, 0.0f);
			controller.mHighFreq = VuMax(controller.mHighFreq, 0.0f);
		}
		else
		{
			if ( controller.mIsConnected )
			{
				controller.zero();
				controller.mIsConnected = false;
				controller.mDeviceId = 0;
				controller.mLowFreq = 0.0f;
				controller.mHighFreq = 0.0f;

				VuParams params;
				params.addInt(i);
				VuEventManager::IF()->broadcast("OnGamePadConnected", params);
			}
		}
	}
}

//*****************************************************************************
void VuXb1GamePad::VuXb1Controller::playVibrationEffect(int effect)
{
	mLowFreq = VuMax(mLowFreq, sVibrationEffects[effect].mLowFreq);
	mHighFreq = VuMax(mHighFreq, sVibrationEffects[effect].mHighFreq);
}

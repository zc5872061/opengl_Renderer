//*****************************************************************************
//
//  Copyright (c) 2014-2014 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Android Audio HAL
//
//*****************************************************************************

#include "VuAndroidAudio.h"



static int g_gameBaseAudioState = 0; //0 ���ù�   1��ʾ��  2 ��ʾ �ر�


// the interface
IMPLEMENT_SYSTEM_COMPONENT(VuAudio, VuAndroidAudio);


// static JAVA stuff
static JNIEnv		*s_jniEnv;
static jobject		s_helperObject;
static jmethodID	s_isDolbyAudioProcessingSupported;
static jmethodID	s_isDolbyAudioProcessingEnabled;
static jmethodID	s_setDolbyAudioProcessingEnabled;


bool VuAndroidAudio::init()
{
	//modify by xlm
	bool bRet = VuAudio::init();
/*
	if (bRet)
	{

		//modify by xlm
		int nState = VuAndroidAudio::GetGameBaseAudioState();
		
		if (nState == 1)
		{

			__android_log_print(ANDROID_LOG_DEBUG, "Audio", "set gamebase audio == 1 begin");

#if !VU_DISABLE_AUDIO

			VuSettingsManager::IF()->setEffectVolume(1);
			VuSettingsManager::IF()->setMusicVolume(1);
			
			__android_log_print(ANDROID_LOG_DEBUG, "Audio", "set gamebase audio nState == 1");
#endif // !VU_DISABLE_AUDIO

		}
		else if (nState == 2)
		{
			__android_log_print(ANDROID_LOG_DEBUG, "Audio", "set gamebase audio == 2 begin");

		

#if !VU_DISABLE_AUDIO

			VuSettingsManager::IF()->setEffectVolume(0);
			VuSettingsManager::IF()->setMusicVolume(0);
			
			__android_log_print(ANDROID_LOG_DEBUG, "Audio", "set gamebase audio nState == 2");
#endif // !VU_DISABLE_AUDIO

		}
		else
		{
			__android_log_print(ANDROID_LOG_DEBUG, "Audio", "set gamebase audio nState == 0");

		}
	}*/
	return bRet;
}


//*****************************************************************************
void VuAndroidAudio::bindJavaMethods(JNIEnv *jniEnv, jobject classLoaderObject, jmethodID findClassMethod)
{
	__android_log_print(ANDROID_LOG_DEBUG, "Audio",  "VuAndroidAudio::bindJavaMethods()\n");

	s_jniEnv = jniEnv;

	// get reference to helper class object
	jstring helperClassName = jniEnv->NewStringUTF("com/vectorunit/VuAudioHelper");
	jclass helperClass = (jclass)jniEnv->CallObjectMethod(classLoaderObject, findClassMethod, helperClassName);
	jniEnv->DeleteLocalRef(helperClassName);

	jmethodID getInstance = jniEnv->GetStaticMethodID(helperClass, "getInstance", "()Lcom/vectorunit/VuAudioHelper;");
	jobject helperObject = jniEnv->CallStaticObjectMethod(helperClass, getInstance);
	s_helperObject = jniEnv->NewGlobalRef(helperObject);

	// methods
	s_isDolbyAudioProcessingSupported = jniEnv->GetMethodID(helperClass, "isDolbyAudioProcessingSupported", "()Z");
	s_isDolbyAudioProcessingEnabled = jniEnv->GetMethodID(helperClass, "isDolbyAudioProcessingEnabled", "()Z");
	s_setDolbyAudioProcessingEnabled = jniEnv->GetMethodID(helperClass, "setDolbyAudioProcessingEnabled", "(Z)V");
}

//*****************************************************************************
bool VuAndroidAudio::isDolbyAudioProcessingSupported()
{
	return s_jniEnv->CallBooleanMethod(s_helperObject, s_isDolbyAudioProcessingSupported);
}

//*****************************************************************************
bool VuAndroidAudio::isDolbyAudioProcessingEnabled()
{
	return s_jniEnv->CallBooleanMethod(s_helperObject, s_isDolbyAudioProcessingEnabled);
}

//*****************************************************************************
void VuAndroidAudio::setDolbyAudioProcessingEnabled(bool enable)
{
	s_jniEnv->CallBooleanMethod(s_helperObject, s_setDolbyAudioProcessingEnabled, enable);
}




extern "C"
{
	JNIEXPORT void JNICALL Java_com_vectorunit_VuAudioHelper_EnableAudio(JNIEnv *env, jobject obj, jboolean enable);
}


JNIEXPORT void JNICALL Java_com_vectorunit_VuAudioHelper_EnableAudio(JNIEnv *env, jobject obj, jboolean enable)
{
#if !VU_DISABLE_AUDIO

	__android_log_print(ANDROID_LOG_DEBUG, "bbr_audio", "Java_com_vectorunit_VuAudioHelper_EnableAudio\n");

	g_gameBaseAudioState = enable > 0 ? 1 : 2;

	/*if (!VuAudio::IF())
	{
		__android_log_print(ANDROID_LOG_DEBUG, "bbr_audio", "Java_com_vectorunit_VuAudioHelper_EnableAudio  vuaudio is not ready!\n");
		return;

	}*/

	
/*

	float fVol = enable > 0 ? 1.0 : 0.0;
	FMOD::EventCategory *pCategory;
	if (VuAudio::IF()->eventSystem()->getCategory("music", &pCategory) == FMOD_OK)
		pCategory->setVolume(fVol);

	if (VuAudio::IF()->eventSystem()->getCategory("game", &pCategory) == FMOD_OK)
		pCategory->setVolume(fVol);

	if (VuAudio::IF()->eventSystem()->getCategory("ui", &pCategory) == FMOD_OK)
		pCategory->setVolume(fVol);

	__android_log_print(ANDROID_LOG_DEBUG, "bbr_audio", "Java_com_vectorunit_VuAudioHelper_EnableAudio finish\n");*/
#endif
}


/*
@ Author:	xlm(2015-4-10 14:45)
@ Parameter:
@ Returns:
@ Description:
*/
int VuAndroidAudio::GetGameBaseAudioState()
{
	return g_gameBaseAudioState;
}

void VuAndroidAudio::SetGameBaseAudioState(int nState)
{
	g_gameBaseAudioState = nState;
}

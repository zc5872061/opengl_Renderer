//*****************************************************************************
//
//  Copyright (c) 2011-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Interface class to File library.
// 
//*****************************************************************************

#include <sys/stat.h>
#include "VuWindowsFile.h"
#include "VuEngine/Util/VuFileUtil.h"
#include "VuEngine/Util/VuUtf8.h"
#include "VuEngine/Dev/VuDevHostComm.h"


// the interface
IMPLEMENT_SYSTEM_COMPONENT(VuFile, VuWindowsFile);

// static variables
static std::string sLocalFolder;


//*****************************************************************************
bool VuWindowsFile::init(const std::string &rootPath, const std::string &projectName)
{
	if ( !VuGenericWinFile::init(rootPath, projectName) )
		return false;

	if ( projectName.length() )
	{
		mCachePath = sLocalFolder + "\\" + projectName;

		struct stat status;
		if ( stat(mCachePath.c_str(), &status) == -1 )
		{
			wchar_t wpath[MAX_PATH];
			VuUtf8::convertUtf8StringToWCharString(mCachePath.c_str(), wpath, MAX_PATH);
			if ( !CreateDirectoryW(wpath, VUNULL) )
				return false;
		}

		mCachePath = VuFileUtil::fixSlashes(mCachePath);
		mCachePath += "/";
	}

	return true;
}

//*****************************************************************************
void VuWindowsFile::getLocalFolder(std::string &localFolder)
{
	VuUtf8::convertWCharStringToUtf8String(Windows::Storage::ApplicationData::Current->LocalFolder->Path->Data(), localFolder);
}
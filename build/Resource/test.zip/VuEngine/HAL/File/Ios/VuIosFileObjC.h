//*****************************************************************************
//
//  Copyright (c) 2011-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Objective-C support for Ios File interface.
//
//*****************************************************************************

#pragma once


namespace VuIosFileObjC
{
	bool GetDocumentPath(char *path, int size);
}

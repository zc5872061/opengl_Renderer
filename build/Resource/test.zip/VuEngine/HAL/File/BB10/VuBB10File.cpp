//*****************************************************************************
//
//  Copyright (c) 2013-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Interface class to File library.
// 
//*****************************************************************************

#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include "VuBB10File.h"
#include "VuEngine/Util/VuFileUtil.h"
#include "VuEngine/HAL/File/VuFileHostIO.h"


// the interface
IMPLEMENT_SYSTEM_COMPONENT(VuFile, VuBB10File);


//*****************************************************************************
bool VuBB10File::init(const std::string &rootPath, const std::string &projectName)
{
	if ( !VuGenericFile::init(rootPath, projectName) )
		return false;
	
	// get working directory
	char appPath[256];
	getcwd(appPath, sizeof(appPath));

	mDataPath = std::string(appPath) + "/data";
	
	if ( projectName.length() )
	{
		mCachePath = std::string(appPath) + "/data";
	}
	
	return true;
}

//*****************************************************************************
void VuBB10File::enumFiles(VuFile::FileList &fileList, const std::string &strSearchPath, const std::string &strWildCard)
{
#if !VU_DISABLE_DEV_HOST_COMM
	if ( mpHostIO && mpHostIO->isHostPath(getRootPath()) )
		mpHostIO->enumFiles(fileList, strSearchPath, strWildCard);
#endif
	
	// build search path
	std::string strSearch = VuFileUtil::fixSlashes(getRootPath() + strSearchPath + "/" + strWildCard);
	
	if ( DIR *pDir = opendir(strSearch.c_str()) )
	{
		std::string nameWildCard = VuFileUtil::getName(strWildCard);
		std::string extWildCard = VuFileUtil::getExt(strWildCard);
		
		dirent *pDirEnt;
		while ( (pDirEnt = readdir(pDir)) != NULL )
		{
			if ( nameWildCard != "*" )
				if ( VuFileUtil::getName(pDirEnt->d_name) != nameWildCard )
					continue;
			
			if ( extWildCard != "*" )
				if ( VuFileUtil::getExt(pDirEnt->d_name) != extWildCard )
					continue;
			
			fileList.push_back(pDirEnt->d_name);
		}
		
		closedir(pDir);
	}
}

//*****************************************************************************
bool VuBB10File::createDirectory(const std::string &strPath)
{
#if !VU_DISABLE_DEV_HOST_COMM
	if ( mpHostIO && mpHostIO->isHostPath(getRootPath()) )
		return mpHostIO->createDirectory(strPath);
#endif
	
	std::string cleanPath = VuFileUtil::fixSlashes(strPath);
	while ( cleanPath.length() && cleanPath[cleanPath.length() - 1] == '/' )
		cleanPath.resize(cleanPath.length() - 1);
	
	if ( exists(cleanPath) )
		return true;
	
	std::string parentPath = VuFileUtil::getPath(cleanPath);
	if ( parentPath.length() )
		if ( !createDirectory(parentPath) )
			return false;
	
	std::string strFullPath = getRootPath() + cleanPath;
	
	if ( mkdir(strFullPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO) == -1 )
	{
		if ( errno != EEXIST )
			return false;
	}
	
	return true;
}

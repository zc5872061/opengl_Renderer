//*****************************************************************************
//
//  Copyright (c) 2013-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  BB10 interface class for File.
//
//*****************************************************************************

#pragma once

#include "VuEngine/HAL/File/Generic/VuGenericFile.h"


class VuBB10File : public VuGenericFile
{
private:
	virtual bool		init(const std::string &rootPath, const std::string &projectName);
	
public:
	
	virtual void		enumFiles(FileList &fileList, const std::string &strSearchPath, const std::string &strWildCard);
	
	virtual bool		createDirectory(const std::string &strPath);
	
	// platform-specific functionality
	static VuBB10File *IF() { return static_cast<VuBB10File *>(VuFile::IF()); }
	
	// files path
	const std::string	&getDataPath() { return mDataPath; }
	
private:
	std::string			mDataPath;
};

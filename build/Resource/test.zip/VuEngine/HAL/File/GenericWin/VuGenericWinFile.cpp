//*****************************************************************************
//
//  Copyright (c) 2009-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Generic windows implementation of File Interface.
// 
//*****************************************************************************

#include "VuGenericWinFile.h"
#include "VuEngine/Util/VuFileUtil.h"
#include "VuEngine/Util/VuUtf8.h"
#include "VuEngine/HAL/File/VuFileHostIO.h"


//*****************************************************************************
void VuGenericWinFile::enumFiles(VuFile::FileList &fileList, const std::string &strSearchPath, const std::string &strWildCard)
{
#if !VU_DISABLE_DEV_HOST_COMM
	if ( mpHostIO && mpHostIO->isHostPath(getRootPath()) )
		mpHostIO->enumFiles(fileList, strSearchPath, strWildCard);
#endif

	// build search path
	std::string strSearch = VuFileUtil::fixSlashes(getRootPath() + strSearchPath + "/" + strWildCard);
	convertToNativeFileName(strSearch);

	WIN32_FIND_DATAW fd;
	wchar_t wpath[MAX_PATH];
	VuUtf8::convertUtf8StringToWCharString(strSearch.c_str(), wpath, MAX_PATH);
	HANDLE hSearch = FindFirstFileExW(wpath, FindExInfoBasic, &fd, FindExSearchNameMatch, NULL, 0);
	if ( hSearch == INVALID_HANDLE_VALUE )
		return;

	do
	{
		if ( fd.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN )
			continue;

		if ( fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
			if ( fd.cFileName[0] == '.' )
				continue;

		std::string fileName;
		VuUtf8::convertWCharStringToUtf8String(fd.cFileName, fileName);
		fileList.push_back(fileName);
	}
	while ( FindNextFileW(hSearch, &fd) );

	FindClose(hSearch);
}

//*****************************************************************************
bool VuGenericWinFile::createDirectory(const std::string &strPath)
{
#if !VU_DISABLE_DEV_HOST_COMM
	if ( mpHostIO && mpHostIO->isHostPath(getRootPath()) )
		return mpHostIO->createDirectory(strPath);
#endif

	std::string cleanPath = VuFileUtil::fixSlashes(strPath);
	while ( cleanPath.length() && cleanPath[cleanPath.length() - 1] == '/' )
		cleanPath.resize(cleanPath.length() - 1);

	if ( exists(strPath) )
		return true;

	std::string parentPath = VuFileUtil::getPath(strPath);
	if ( parentPath.length() )
		if ( !createDirectory(parentPath) )
			return false;

	// build filename
	std::string strFullPath = getRootPath() + strPath;
	convertToNativeFileName(strFullPath);

	wchar_t wpath[MAX_PATH];
	VuUtf8::convertUtf8StringToWCharString(strFullPath.c_str(), wpath, MAX_PATH);
	if ( !CreateDirectoryW(wpath, VUNULL) )
		return false;

	return true;
}

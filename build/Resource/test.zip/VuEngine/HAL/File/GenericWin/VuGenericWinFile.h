//*****************************************************************************
//
//  Copyright (c) 2009-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Generic windows implementation of File Interface.
// 
//*****************************************************************************

#include "VuEngine/HAL/File/Generic/VuGenericFile.h"


class VuGenericWinFile : public VuGenericFile
{
public:
	virtual void				enumFiles(FileList &fileList, const std::string &strSearchPath, const std::string &strWildCard);

	virtual bool				createDirectory(const std::string &strPath);
};

//*****************************************************************************
//
//  Copyright (c) 2013-2013 Vector Unit Inc
//  Confidential Trade Secrets
// 
//  Interface class to File library.
// 
//*****************************************************************************

#include <kernel.h>
#include "VuEngine/HAL/File/Generic/VuGenericFile.h"
#include "VuEngine/HAL/File/VuFileHostIO.h"
#include "VuEngine/Util/VuFileUtil.h"


//*****************************************************************************
class VuPs4File : public VuGenericFile
{
private:
	virtual bool		init(const std::string &rootPath, const std::string &projectName);
	
public:
	
	virtual void		enumFiles(FileList &fileList, const std::string &strSearchPath, const std::string &strWildCard);
	
	virtual bool		createDirectory(const std::string &strPath);
};

// the interface
IMPLEMENT_SYSTEM_COMPONENT(VuFile, VuPs4File);


//*****************************************************************************
bool VuPs4File::init(const std::string &rootPath, const std::string &projectName)
{
	if ( !VuGenericFile::init(rootPath, projectName) )
		return false;

	// note:  this may not work on PS4... may need to cache using the SaveData library
	if ( projectName.length() )
	{
		mCachePath = "/data";
	}
	
	return true;
}

//*****************************************************************************
void VuPs4File::enumFiles(VuFile::FileList &fileList, const std::string &strSearchPath, const std::string &strWildCard)
{
#if !VU_DISABLE_DEV_HOST_COMM
	if ( mpHostIO && mpHostIO->isHostPath(getRootPath()) )
		mpHostIO->enumFiles(fileList, strSearchPath, strWildCard);
#endif

	VUASSERT(0, "Not implemented yet!");
}

//*****************************************************************************
bool VuPs4File::createDirectory(const std::string &strPath)
{
#if !VU_DISABLE_DEV_HOST_COMM
	if ( mpHostIO && mpHostIO->isHostPath(getRootPath()) )
		return mpHostIO->createDirectory(strPath);
#endif
	
	std::string cleanPath = VuFileUtil::fixSlashes(strPath);
	while ( cleanPath.length() && cleanPath[cleanPath.length() - 1] == '/' )
		cleanPath.resize(cleanPath.length() - 1);
	
	if ( exists(cleanPath) )
		return true;
	
	std::string parentPath = VuFileUtil::getPath(cleanPath);
	if ( parentPath.length() )
		if ( !createDirectory(parentPath) )
			return false;
	
	std::string strFullPath = getRootPath() + cleanPath;
	
	if ( mkdir(strFullPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO) == -1 )
	{
		if ( errno != EEXIST )
			return false;
	}
	
	return true;
}
